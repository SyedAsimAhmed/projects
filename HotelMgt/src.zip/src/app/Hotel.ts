export class Hotel {
  id: string;
  name: string;
  hostname: string;
  neighbourhoodgroup: string;
  neighbourhood: string;
  latitude: string;
  longitude: string;
  roomtype: string;
  price: string;
}
